// first-sun.js (v2)  ·  "When does the coast finally see the sun?"
// Requires d3 v7 loaded globally. Styles live in first-sun.css.
//
//   initFirstSun(rootElement, data, { basemap })
//   data     = { grid, hours, nDays, getFrame }   (see first-sun-data.js)
//   basemap  = GeoJSON FeatureCollection of US states (topojson.feature(us, us.objects.states))
//
// How the map works: for every screen pixel we interpolate the satellite grid smoothly, find the
// hour at which cloud chance first drops to the threshold (interpolating between hours too), and
// color that moment. Thin lines mark each whole hour.

const VIEWS = [
  {
    id: 'sf', name: 'San Francisco', lat: [37.35, 38.05], lon: [-122.9, -122.0],
    box: { lat: [37.60, 37.90], lon: [-122.55, -122.35] }
  },
  {
    id: 'sd', name: 'San Diego', lat: [32.45, 33.15], lon: [-117.6, -116.8],
    box: { lat: [32.65, 33.00], lon: [-117.30, -117.10] }
  },
];

// Early sun is warm yellow, late sun is deep indigo. Lightness falls steadily, so order is readable.
const PALETTE = ['#ffe27a', '#f6a55b', '#d65f78', '#6a3d92', '#24285f'];
const NEVER_LAND = [142, 152, 167];
const NEVER_WATER = [188, 196, 208];
const NO_DATA = [238, 240, 244];

function fmtTime(h) {
  let m = Math.round((h * 60) / 5) * 5;
  const hh = Math.floor(m / 60), mm = m % 60;
  return `${((hh + 11) % 12) + 1}:${String(mm).padStart(2, '0')} ${hh < 12 ? 'AM' : 'PM'}`;
}
const fmtHour = h => `${((h + 11) % 12) + 1} ${h < 12 ? 'AM' : 'PM'}`;
const fmtDay = d => `June ${d + 1}`;
function fmtDur(min) {
  const m = Math.round(min / 5) * 5;
  if (m < 60) return `${m} minutes`;
  const h = Math.floor(m / 60), r = m % 60;
  return r ? `${h} hr ${r} min` : `${h} hr`;
}

export function initFirstSun(root, data, opts = {}) {
  const { grid, hours, nDays, getFrame } = data;
  const nH = hours.length, nPix = grid.nLat * grid.nLon;
  const sunriseHour = opts.sunriseHour ?? 6;
  const sunriseIdx = Math.max(0, hours.findIndex(h => h >= sunriseHour));
  const hMin = hours[sunriseIdx], hMax = hours[nH - 1];
  const S = opts.resolution ?? 2;                         // screen px per field cell (smaller = sharper, slower)

  // ---------- June-average cloud chance per pixel per hour ----------
  const avg = hours.map(() => new Float32Array(nPix));
  const cnt = hours.map(() => new Uint8Array(nPix));
  for (let d = 0; d < nDays; d++) {
    for (let h = 0; h < nH; h++) {
      const f = getFrame(d, h);
      for (let p = 0; p < nPix; p++) { const v = f[p]; if (v !== 255) { avg[h][p] += v; cnt[h][p]++; } }
    }
  }
  for (let h = 0; h < nH; h++) for (let p = 0; p < nPix; p++) avg[h][p] = cnt[h][p] ? avg[h][p] / cnt[h][p] : NaN;

  let dayField = null;
  function setDay(day) {
    dayField = hours.map((_, h) => {
      const f = getFrame(day, h), o = new Float32Array(nPix);
      for (let p = 0; p < nPix; p++) o[p] = f[p] === 255 ? NaN : f[p];
      return o;
    });
  }

  // ---------- color lookup ----------
  const interp = d3.interpolateRgbBasis(PALETTE);
  const lut = Array.from({ length: 256 }, (_, i) => { const c = d3.rgb(interp(i / 255)); return [c.r, c.g, c.b]; });
  const colorAt = v => lut[Math.max(0, Math.min(255, Math.round(((v - hMin) / (hMax - hMin)) * 255)))];

  // ---------- state ----------
  const state = { mode: 'avg', thr: 0.5, day: opts.startDay ?? 13, hover: null };
  setDay(state.day);

  // ---------- DOM ----------
  root.classList.add('fs-root');
  root.innerHTML = `
    <div class="fs-controls">
      <div class="fs-seg" role="radiogroup" aria-label="Which mornings to show">
        <label><input type="radio" name="fs-mode" value="avg" checked><span>June typical</span></label>
        <label><input type="radio" name="fs-mode" value="day"><span>One day</span></label>
      </div>
      <label class="fs-slider fs-thr">
        <span class="fs-slider-label">Sunny means cloud chance of at most <output>50%</output></span>
        <input type="range" min="10" max="90" step="5" value="50">
      </label>
      <label class="fs-slider fs-day" hidden>
        <span class="fs-slider-label">Day <output>${fmtDay(state.day)}</output></span>
        <input type="range" min="0" max="${nDays - 1}" step="1" value="${state.day}">
      </label>
    </div>
    <p class="fs-takeaway" aria-live="polite"></p>
    <div class="fs-maps"></div>
    <div class="fs-legend"></div>
    <div class="fs-inset" aria-live="polite"><p class="fs-hint">Hover a spot on either map to see what its morning looks like.</p></div>
    <p class="fs-note">Hours before sunrise (about 5:45 AM) are left out because the satellite is less reliable in the dark. The map is smoothed between satellite pixels (about 3 km each) for readability.</p>`;

  const mapsEl = root.querySelector('.fs-maps');
  const rootW = root.clientWidth || 940;
  const gap = 20;
  const W = rootW < 700 ? Math.max(260, rootW) : Math.min(520, Math.floor((rootW - gap) / 2));
  const panels = VIEWS.map(v => buildPanel(v, W));

  // ---------- panel construction ----------
  function buildPanel(view, W) {
    const corners = {
      type: 'MultiPoint', coordinates: [
        [view.lon[0], view.lat[0]], [view.lon[1], view.lat[0]], [view.lon[1], view.lat[1]], [view.lon[0], view.lat[1]]]
    };
    const projection = d3.geoMercator().fitWidth(W, corners);
    const H = Math.ceil(d3.geoPath(projection).bounds(corners)[1][1]);
    const fw = Math.ceil(W / S), fh = Math.ceil(H / S), n = fw * fh;

    const fig = document.createElement('figure');
    fig.className = 'fs-panel';
    fig.innerHTML = `
      <figcaption>
        <span class="fs-city">${view.name}</span>
        <span class="fs-big">–</span>
        <span class="fs-sub">typical first sun on the coast</span>
      </figcaption>
      <div class="fs-canvas-wrap"><canvas></canvas><div class="fs-tip" hidden></div></div>`;
    mapsEl.appendChild(fig);
    const canvas = fig.querySelector('canvas');
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    canvas.style.aspectRatio = `${W} / ${H}`;
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);

    // land mask (rasterize basemap, sample)
    let landData = null;
    if (opts.basemap) {
      const off = document.createElement('canvas'); off.width = W; off.height = H;
      const octx = off.getContext('2d');
      octx.fillStyle = '#000'; octx.beginPath(); d3.geoPath(projection, octx)(opts.basemap); octx.fill();
      landData = octx.getImageData(0, 0, W, H).data;
    }
    const isLand = (x, y) => {
      if (!landData) return 1;
      const xi = Math.min(W - 1, Math.max(0, Math.round(x))), yi = Math.min(H - 1, Math.max(0, Math.round(y)));
      return landData[(yi * W + xi) * 4 + 3] > 0 ? 1 : 0;
    };

    // per field-cell sampling info
    const i0 = new Int32Array(n), j0 = new Int32Array(n), tx = new Float32Array(n), ty = new Float32Array(n);
    const ok = new Uint8Array(n), land = new Uint8Array(n), inBox = new Uint8Array(n);
    const [bx0, by1] = projection([view.box.lon[0], view.box.lat[0]]);
    const [bx1, by0] = projection([view.box.lon[1], view.box.lat[1]]);
    for (let sy = 0; sy < fh; sy++) for (let sx = 0; sx < fw; sx++) {
      const k = sy * fw + sx, x = (sx + 0.5) * S, y = (sy + 0.5) * S;
      const [lon, lat] = projection.invert([x, y]);
      const gx = (lon - grid.lon0) / grid.dlon - 0.5, gy = (lat - grid.lat0) / grid.dlat - 0.5;
      const ii = Math.floor(gy), jj = Math.floor(gx);
      if (ii < 0 || jj < 0 || ii >= grid.nLat - 1 || jj >= grid.nLon - 1) continue;
      i0[k] = ii; j0[k] = jj; tx[k] = gx - jj; ty[k] = gy - ii; ok[k] = 1;
      land[k] = isLand(x, y);
      inBox[k] = (x >= bx0 && x <= bx1 && y >= by0 && y <= by1) ? 1 : 0;
    }

    const fieldCanvas = document.createElement('canvas'); fieldCanvas.width = fw; fieldCanvas.height = fh;
    const fctx = fieldCanvas.getContext('2d');
    const imgData = fctx.createImageData(fw, fh);

    const pn = {
      view, W, H, fw, fh, n, projection, canvas, ctx, i0, j0, tx, ty, ok, land, inBox,
      fieldCanvas, fctx, imgData, vals: new Float32Array(n),
      big: fig.querySelector('.fs-big'), tip: fig.querySelector('.fs-tip'), median: NaN, bx: [bx0, by0, bx1, by1]
    };

    canvas.addEventListener('mousemove', ev => {
      const r = canvas.getBoundingClientRect();
      const x = (ev.clientX - r.left) * (W / r.width), y = (ev.clientY - r.top) * (H / r.height);
      const k = Math.floor(y / S) * fw + Math.floor(x / S);
      if (!(k >= 0 && k < n) || !ok[k]) return;
      state.hover = { pn, k, x, y };
      draw(); showTip(pn, k, ev.clientX - r.left, ev.clientY - r.top); drawInset();
    });
    canvas.addEventListener('mouseleave', () => { state.hover = null; pn.tip.hidden = true; draw(); });
    return pn;
  }

  // ---------- sampling & first-sun calculation ----------
  function sample(field, pn, k) {
    const nl = grid.nLon, p = pn.i0[k] * nl + pn.j0[k], a = pn.tx[k], b = pn.ty[k];
    const v = [field[p], field[p + 1], field[p + nl], field[p + nl + 1]];
    const w = [(1 - a) * (1 - b), a * (1 - b), (1 - a) * b, a * b];
    let s = 0, ws = 0;
    for (let q = 0; q < 4; q++) if (v[q] === v[q]) { s += v[q] * w[q]; ws += w[q]; }
    return ws > 0.25 ? s / ws : NaN;
  }
  // First time (in fractional hours) the cloud chance drops to the threshold, or NaN if it never does.
  function firstSun(fields, thr, pn, k) {
    let prev = NaN, prevH = -1;
    for (let h = sunriseIdx; h < nH; h++) {
      const v = sample(fields[h], pn, k);
      if (v === v && v <= thr) {
        if (h === sunriseIdx || prev !== prev) return hours[h];
        const t = (prev - thr) / (prev - v);
        return hours[prevH] + t * (hours[h] - hours[prevH]);
      }
      if (v === v) { prev = v; prevH = h; }
    }
    return NaN;
  }

  // ---------- render ----------
  function currentFields() {
    return state.mode === 'avg' ? { fields: avg, thr: state.thr } : { fields: dayField, thr: 0.5 };
  }

  function renderPanel(pn) {
    const { fields, thr } = currentFields();
    const { n, vals, imgData, ok, land, inBox } = pn;
    const px = imgData.data, cvals = new Float32Array(n), inBoxVals = [];
    for (let k = 0; k < n; k++) {
      let v = NaN;
      if (ok[k]) v = firstSun(fields, thr, pn, k);
      vals[k] = v;
      const o = k * 4;
      let c;
      if (!ok[k]) c = NO_DATA; else if (v !== v) c = land[k] ? NEVER_LAND : NEVER_WATER; else c = colorAt(v);
      px[o] = c[0]; px[o + 1] = c[1]; px[o + 2] = c[2]; px[o + 3] = 255;
      cvals[k] = ok[k] && v === v ? v : hMax + 2;
      if (inBox[k] && land[k]) inBoxVals.push(v === v ? v : Infinity);
    }
    pn.fctx.putImageData(imgData, 0, 0);
    pn.contours = d3.contours().size([pn.fw, pn.fh]).thresholds(d3.range(hMin + 1, hMax + 1))(cvals);
    inBoxVals.sort(d3.ascending);
    pn.median = inBoxVals.length ? d3.quantile(inBoxVals, 0.5) : NaN;
    pn.neverShare = inBoxVals.length ? inBoxVals.filter(v => v === Infinity).length / inBoxVals.length : 0;
    pn.big.textContent = pn.median !== pn.median ? '–' : (pn.median === Infinity ? 'after noon' : fmtTime(pn.median));
  }

  function draw() {
    for (const pn of panels) {
      const { ctx, W, H, fw, fh, projection } = pn;
      ctx.clearRect(0, 0, W, H);
      ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(pn.fieldCanvas, 0, 0, fw, fh, 0, 0, fw * S, fh * S);
      // hour contours
      ctx.save(); ctx.scale(S, S);
      ctx.lineJoin = 'round'; ctx.lineWidth = 0.9 / S; ctx.strokeStyle = 'rgba(255,255,255,.7)';
      const path = d3.geoPath(null, ctx);
      for (const c of pn.contours) { ctx.beginPath(); path(c); ctx.stroke(); }
      ctx.restore();
      // coastline
      if (opts.basemap) {
        ctx.beginPath(); d3.geoPath(projection, ctx)(opts.basemap);
        ctx.strokeStyle = 'rgba(16,20,32,.85)'; ctx.lineWidth = 1.1; ctx.stroke();
      }
      // measurement box
      const [x0, y0, x1, y1] = pn.bx;
      ctx.setLineDash([5, 3]); ctx.strokeStyle = '#101420'; ctx.lineWidth = 1.4;
      ctx.strokeRect(x0, y0, x1 - x0, y1 - y0); ctx.setLineDash([]);
      // hover ring
      if (state.hover && state.hover.pn === pn) {
        ctx.beginPath(); ctx.arc(state.hover.x, state.hover.y, 6, 0, Math.PI * 2);
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 3.5; ctx.stroke();
        ctx.strokeStyle = '#101420'; ctx.lineWidth = 1.5; ctx.stroke();
      }
    }
  }

  function showTip(pn, k, cx, cy) {
    const v = pn.vals[k];
    pn.tip.hidden = false;
    pn.tip.textContent = (v === v ? `Sun by ${fmtTime(v)}` : 'Still cloudy at noon') + (pn.land[k] ? '' : ' · open water');
    pn.tip.style.left = Math.min(cx + 14, pn.canvas.clientWidth - 150) + 'px';
    pn.tip.style.top = Math.max(0, cy - 34) + 'px';
  }

  function drawLegend() {
    const el = root.querySelector('.fs-legend');
    const stops = d3.range(0, 11).map(i => { const c = lut[Math.round((i / 10) * 255)]; return `rgb(${c[0]},${c[1]},${c[2]})`; });
    const ticks = d3.range(hMin, hMax + 1).map(h => {
      const pct = ((h - hMin) / (hMax - hMin)) * 100;
      return `<span style="left:${pct}%">${fmtHour(h).replace(' ', '')}</span>`;
    }).join('');
    el.innerHTML = `
      <div class="fs-scale">
        <div class="fs-bar" style="background:linear-gradient(to right, ${stops.join(',')})"></div>
        <div class="fs-ticks">${ticks}</div>
        <div class="fs-scale-title">First sunny hour</div>
      </div>
      <div class="fs-keys">
        <span class="fs-key-item"><i class="fs-sw" style="background:rgb(${NEVER_LAND})"></i>still cloudy at noon</span>
        <span class="fs-key-item"><i class="fs-line"></i>each whole hour</span>
        <span class="fs-key-item"><i class="fs-dash"></i>coast used for the time above</span>
      </div>`;
  }

  // ---------- takeaway sentence built from the numbers ----------
  function writeTakeaway() {
    const el = root.querySelector('.fs-takeaway');
    const [a, b] = panels;
    if (a.median !== a.median || b.median !== b.median) { el.textContent = ''; return; }
    const when = state.mode === 'avg' ? 'On a typical June morning' : `On ${fmtDay(state.day)}`;
    if (a.median === Infinity && b.median === Infinity) { el.textContent = `${when}, neither coast has cleared by noon.`; return; }
    if (a.median === Infinity || b.median === Infinity) {
      const [stuck, clear] = a.median === Infinity ? [a, b] : [b, a];
      el.textContent = `${when}, ${stuck.view.name}'s coast is still mostly cloudy at noon, while ${clear.view.name}'s sees the sun by ${fmtTime(clear.median)}.`;
      return;
    }
    const diff = (b.median - a.median) * 60;
    if (Math.abs(diff) < 10) { el.textContent = `${when}, the two coasts see the sun at about the same time, around ${fmtTime((a.median + b.median) / 2)}.`; return; }
    const [early, late] = diff > 0 ? [a, b] : [b, a];
    el.textContent = `${when}, ${late.view.name}'s coast sees the sun about ${fmtDur(Math.abs(diff))} later than ${early.view.name}'s (${fmtTime(late.median)} versus ${fmtTime(early.median)}).`;
  }

  // ---------- hover inset: that spot's morning ----------
  function drawInset() {
    const el = root.querySelector('.fs-inset');
    if (!state.hover) return;
    const { pn, k } = state.hover;
    const w = 560, h = 190, m = { t: 14, r: 14, b: 28, l: 40 };
    const x = d3.scaleLinear().domain([hours[0], hMax]).range([m.l, w - m.r]);
    const y = d3.scaleLinear().domain([0, 1]).range([h - m.b, m.t]);
    const v = pn.vals[k];
    const avgSeries = hours.map((hr, q) => ({ hr, a: sample(avg[q], pn, k) }));
    const line = d3.line().curve(d3.curveMonotoneX).defined(d => d.a === d.a).x(d => x(d.hr)).y(d => y(d.a));
    const dayPath = state.mode === 'day'
      ? line(hours.map((hr, q) => ({ hr, a: sample(dayField[q], pn, k) }))) : null;
    const { thr } = currentFields();
    el.innerHTML = `
      <div class="fs-inset-head"><strong>${pn.view.name}</strong>${pn.land[k] ? '' : ' · open water'}
        · ${v === v ? `first sun ${fmtTime(v)}` : 'still cloudy at noon'}
        <span class="fs-muted">(${state.mode === 'day' ? fmtDay(state.day) : 'June typical'})</span></div>
      <svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Chance of cloud by hour at the hovered spot">
        <rect x="${x(hours[0])}" y="${m.t}" width="${Math.max(0, x(hMin) - x(hours[0]))}" height="${h - m.b - m.t}" class="fs-shade"/>
        <text x="${x(hours[0]) + 4}" y="${m.t + 12}" class="fs-svg-note">less reliable</text>
        ${[0, 0.5, 1].map(t => `<line x1="${m.l}" x2="${w - m.r}" y1="${y(t)}" y2="${y(t)}" class="fs-grid"/>
          <text x="${m.l - 6}" y="${y(t) + 4}" text-anchor="end" class="fs-svg-tick">${t * 100}%</text>`).join('')}
        ${state.mode === 'avg' ? `<line x1="${m.l}" x2="${w - m.r}" y1="${y(thr)}" y2="${y(thr)}" class="fs-thr-line"/>
          <text x="${w - m.r}" y="${y(thr) - 5}" text-anchor="end" class="fs-svg-note">sunny threshold</text>` : ''}
        <path d="${line(avgSeries)}" class="fs-avg-line"/>
        ${dayPath ? `<path d="${dayPath}" class="fs-day-line"/>` : ''}
        ${v === v ? `<line x1="${x(v)}" x2="${x(v)}" y1="${m.t}" y2="${h - m.b}" class="fs-sun-line"/>
          <text x="${Math.min(x(v) + 6, w - 70)}" y="${h - m.b - 6}" class="fs-svg-sun">${fmtTime(v)}</text>` : ''}
        ${hours.filter((_, q) => q % 2 === 0).map(hr => `<text x="${x(hr)}" y="${h - 9}" text-anchor="middle" class="fs-svg-tick">${fmtHour(hr).replace(' ', '')}</text>`).join('')}
      </svg>
      <p class="fs-key-line"><i class="fs-sw-line fs-sw-avg"></i>share of June days cloudy at this hour
        ${dayPath ? '<i class="fs-sw-line fs-sw-day"></i>the selected day (1 = cloudy)' : ''}</p>`;
  }

  // ---------- update loop ----------
  let queued = false;
  function recompute() {
    if (queued) return; queued = true;
    requestAnimationFrame(() => {
      queued = false;
      panels.forEach(renderPanel);
      draw(); writeTakeaway(); drawInset();
    });
  }

  // ---------- controls ----------
  const thrWrap = root.querySelector('.fs-thr'), dayWrap = root.querySelector('.fs-day');
  root.querySelectorAll('input[name="fs-mode"]').forEach(r => r.addEventListener('change', e => {
    state.mode = e.target.value;
    thrWrap.hidden = state.mode !== 'avg'; dayWrap.hidden = state.mode !== 'day';
    recompute();
  }));
  thrWrap.querySelector('input').addEventListener('input', e => {
    state.thr = +e.target.value / 100;
    thrWrap.querySelector('output').textContent = e.target.value + '%'; recompute();
  });
  dayWrap.querySelector('input').addEventListener('input', e => {
    state.day = +e.target.value; setDay(state.day);
    dayWrap.querySelector('output').textContent = fmtDay(state.day);
    opts.onDayChange?.(state.day); recompute();
  });

  drawLegend();
  panels.forEach(renderPanel);
  draw(); writeTakeaway();

  return {
    showDay(d) {
      state.mode = 'day'; state.day = d; setDay(d);
      root.querySelector('input[value="day"]').checked = true;
      thrWrap.hidden = true; dayWrap.hidden = false;
      dayWrap.querySelector('input').value = d; dayWrap.querySelector('output').textContent = fmtDay(d);
      recompute();
    },
  };
}
